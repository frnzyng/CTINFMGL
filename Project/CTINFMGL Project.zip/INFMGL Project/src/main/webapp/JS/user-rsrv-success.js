document.getElementById("return-btn").addEventListener("click", redirectFunction);
        
function redirectFunction(){
    window.location.href = "Reservation.jsp";
}