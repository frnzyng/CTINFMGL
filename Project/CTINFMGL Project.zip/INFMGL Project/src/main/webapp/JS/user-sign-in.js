/*function auth(){
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if (username== "idellolrence" && password== "12345678"){
        window.location.href = "user-reserve.html";
        alert("Sign In Successful");
    } else {
        alert("Sign In Details Incorrect");
        return;
    }
}*/

/*document.getElementById("mainBtn").addEventListener("click", redirectFunction);
        
function redirectFunction(){
    var element
    window.location.href = "user-reserve.html";
}*/